# barcode
PATTERN_DICT = {
    'auto': None,
    'strnaV1.0': 'C6C6C6U6',
    'strnaV2.0': 'C6L15C6L15C6U6T18',
    'strnaV2.1': 'C6L15C6L15C6U8T18',
    'strnaV2.2': 'C4L15C4L15C4U10T18',
    'BBV2.2': {
        'pattern': {
            'L15': 'C4L15C4L15C4U10T18',
        },
        'linker': {
            'p1': ['CGACTCACTACAGGG'],
            'p2': ['TCGGTGACACGATCG'],
        },
    },
    'BBV2.4': {
        'pattern': {
            'L15': 'C4L15C4L15C4U10T18',
            'L16': 'C4L16C4L15C4U10T18',
            'L17': 'C4L17C4L15C4U10T18',
            'L18': 'C4L18C4L15C4U10T18',
        },
        'linker': {
            'p1': ['CGACTCACTACACGT'],
            'p2': ['TCGCTGACACGATCG'],
        },
    },
    'BBV3.1': {
        'pattern': {
            'L15': 'C5L15C5L15C4U10T18',
            'L16': 'C5L16C5L15C4U10T18',
            'L17': 'C5L17C5L15C4U10T18',
            'L18': 'C5L18C5L15C4U10T18',
        },
        'linker': {
            'p1': ['CGACTCACTACACGT'],
            'p2': ['TCGCTGACACGATCG'],
        },
    },
    'customized': None,
}

# count
RAW_MATRIX_DIR_SUFFIX = ['raw_feature_bc_matrix', 'all_matrix']
FILTERED_MATRIX_DIR_SUFFIX = ['filtered_feature_bc_matrix', 'matrix_10X']
MATRIX_FILE_NAME = 'matrix.mtx'
FEATURE_FILE_NAME = 'genes.tsv'
BARCODE_FILE_NAME = 'barcodes.tsv'

# mkref
GENOME_CONFIG = 'celatlas_genome.config'
