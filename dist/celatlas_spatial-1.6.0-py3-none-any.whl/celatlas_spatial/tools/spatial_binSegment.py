
import os
import re
import ast
import json
import tarfile
import argparse
import shutil
import gzip
import cv2
import torch
import skimage
import tifffile
import numpy as np
import pandas as pd
import SimpleITK as sitk
import matplotlib.pyplot as plt

from tqdm import tqdm
from datetime import datetime
from joblib import Parallel, delayed
from scipy.io import mmwrite
from skimage import measure
from skimage.filters import threshold_multiotsu
from skimage.transform import estimate_transform
from segment_anything import SamPredictor, sam_model_registry

from celatlas_spatial.celatlas import ArgFormatter
from celatlas_spatial.tools import utils
from celatlas_spatial.tools import reference
from celatlas_spatial.tools.process import Processor
from celatlas_spatial.tools.image_seg import SwinChipCut
from celatlas_spatial.tools.step import Step, s_common
from celatlas_spatial.tools.matrix import CountMatrix
from celatlas_spatial.rna.mkref import Mkref_rna
from celatlas_spatial.tools.plotly_plot import Table_plot
from celatlas_spatial.tools.__init__ import BARCODE_FILE_NAME, MATRIX_FILE_NAME, FEATURE_FILE_NAME
from celatlas_spatial.__init__ import __VERSION__, ROOT_PATH, HELP_DICT, genome


class SquareBin:
    def __init__(self, micron_bin, bin, tissue_bbox, bin_folder=None, gene_count_detail=None):
        self.micron_bin = micron_bin
        self.tissue_bbox = tissue_bbox
        self.bin = bin
        self.up_row = 0
        self.up_col = 0
        self.num_bits = 0
        self.bin_folder = bin_folder
        self.gene_count_detail = gene_count_detail

    def upsampling_tissue_matrix(self):
        self.up_row = np.ceil(self.tissue_bbox[3] / self.bin).astype(np.int64)
        self.up_col = np.ceil(self.tissue_bbox[2] / self.bin).astype(np.int64)
        self.num_bits = np.ceil(np.log2(self.up_row * self.up_col)).astype(np.int64)
        if self.num_bits % 2 == 1:
            self.num_bits += 1
            self.num_bits = np.int64(self.num_bits)
        mtx = np.zeros((self.up_row, self.up_col), dtype=object)
        return mtx


class BinSegment(Step):
    def __init__(self, args, display_title=None):
        Step.__init__(self, args, display_title=display_title)

        self._bin = 1
        self._parallel = True
        self._raw_show = True
        self._tmp = False
        self._test = self.debug
        self._extend_list = f'{ROOT_PATH}/data/bclist/bclist_V2.0'

        self.bin_exec = None
        self.pixel_size = self.args.pixel_size
        self.bin = np.ceil(np.array(self._micron_bin) / self.pixel_size)

        self.up_row = 0
        self.up_col = 0
        self.num_bits = 0
        self.base_mapping = np.array(['A', 'C', 'G', 'T'], dtype='U1')

        self.tissue_name = self.args.sample
        self.ref_genome = self.args.genomeDir
        self.input = utils.find_directory_by_name(self.args.input, self.args.sample)

        self.count_dir = os.path.join(os.path.dirname(os.path.normpath(self.outdir)), '05.count')
        self.exp_bs_path = self.outdir  # 06.binSegment folder path
        self.exp_bin_im = os.path.join(self.exp_bs_path, 'images')
        self.exp_sq_bin = os.path.join(self.exp_bs_path, 'square_bin')
        self.exp_tmp_path = os.path.join(self.exp_bs_path, 'tmp')

        self.method = self.args.method  # "gene_expr" or "image"
        self.segment_type = self.args.segment_type

        self.segment = self.args.segment
        self.count = self.args.count
        self.rectify = self.args.rectify
        self.extend = self.args.extend

        self.tissue_image_mask = None
        self.he_image_mask = None
        self.he_image = None
        self.gem_mask = None
        self.gem = None
        self.tissue_bbox = np.array(pd.read_csv(self.input['TissueBbox'])['bbox'][0].split('\t')).astype(np.int32)
        self.tissue_image = np.zeros((self.tissue_bbox[2], self.tissue_bbox[3]), dtype=np.uint8)
        self.chip_shape = np.array((self.tissue_bbox[2], self.tissue_bbox[3]), dtype=np.int32)
        self.barcodes_detail = pd.read_csv(self.input['FilterBarcodes'], header=None, names=['x', 'y', 'barcode'])

        if self.segment:
            self.bs_out = os.path.join(self.args.bs_out, self.tissue_name) if self.args.bs_out is not None else None
            self.prompt = ast.literal_eval(self.args.prompt) if self.args.prompt is not None else self.args.prompt
            self.model = self.args.model
            # pre-load tissue image for segmentation
            self.im_path = self.args.tif
            if self.im_path and os.path.exists(self.im_path):
                self.tissue_image = tifffile.imread(self.im_path)
                self.image_d = self.tissue_image.copy()
                if self.tissue_image.dtype != np.uint8:
                    self.tissue_image = utils.convert_8bit(self.tissue_image)
            else:
                self.image_d = np.zeros_like(self.tissue_image)
            if self.bs_out:
                os.makedirs(self.bs_out, exist_ok=True)
            self.counts_path = os.path.join(self.count_dir, f'{self.sample}_counts.txt')
            self.roi_rect = np.array([0] * 4)

        if self.count:
            self.count_detail = self.args.count_detail
            self.tb_position = None
            self.in_bc = None
            self.gene_count_detail = None
            self.raw_count_detail = None
            self.bs_mtx = None
            self.features = None

        if self.rectify:
            self.slice_px = (self.bin[-1] * 10).astype(np.int64)  # 1000 micron here

        if self.extend:
            self._bc_list = pd.read_csv(self._extend_list, header=None)
            self._barcode_extend()

    @utils.add_log
    def prepare(self):
        # create output folder
        os.makedirs(self.exp_bs_path, exist_ok=True)
        os.makedirs(self.exp_bin_im, exist_ok=True)
        os.makedirs(self.exp_sq_bin, exist_ok=True)
        os.makedirs(self.exp_tmp_path, exist_ok=True)

        # prepare some required files
        if self.segment:
            if self.im_path and os.path.exists(self.im_path):
                os.system(f'cp -r {self.im_path} {os.path.join(self.exp_bin_im, f"{self.tissue_name}.tif")}')
                if self.bs_out:
                    os.system(f'cp -r {self.im_path} {os.path.join(self.bs_out, f"{self.tissue_name}.tif")}')

        if self.count:
            bins = self.bin
            bins = np.append(bins, 1.) if self._raw_show else bins
            for i in range(len(bins)):
                if bins[i] != 1:
                    bin_path = os.path.join(self.exp_sq_bin, f'{self.tissue_name}_bin{self._micron_bin[i]}')
                else:
                    bin_path = os.path.join(self.exp_sq_bin, f'{self.tissue_name}_Raw')
                os.makedirs(bin_path, exist_ok=True)
                os.makedirs(os.path.join(bin_path, 'filtered_feature_bc_matrix'), exist_ok=True)
                os.makedirs(os.path.join(bin_path, 'spatial'), exist_ok=True)

                self.scalefactors_json(bin_path, bins[i])
    @staticmethod
    def read_reads_stat(stat_path):
        reads_stat = {}
        pattern = re.compile(r'(\d{1,3},)+\d{3}')

        with open(stat_path, 'r') as f:
            for line in f:
                key, value = line.strip().split(':')
                match = pattern.search(value)
                if match:
                    value = int(match.group().replace(',', ''))
                else:
                    value = value.strip()
                reads_stat[key.strip()] = value
        return reads_stat

    def scalefactors_json(self, output, bin_size):
        hires_scale = 2000 / int(max(self.chip_shape) / bin_size)
        lowres_scale = 600 / int(max(self.chip_shape) / bin_size)

        factors = {
            "tissue_hires_scalef": hires_scale,
            "tissue_lowres_scalef": lowres_scale,
            "fiducial_diameter_fullres": bin_size,
            "spot_diameter_fullres": bin_size
        }
        json_data = json.dumps(factors, indent=4)
        with open(os.path.join(output, 'scalefactors_json.json'), 'w') as json_file:
            json_file.write(json_data)

    @utils.deprecated
    def segment_anything_registration(self, model_path):
        # load sam model
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        sam = sam_model_registry["vit_h"](checkpoint=model_path)
        sam = sam.to(device)
        predictor = SamPredictor(sam)

        # load image and convert to 8bit make sure it can be processed by sam model
        tissue_image = self.tissue_image
        tissue_image = cv2.cvtColor(tissue_image, cv2.COLOR_GRAY2BGR)
        predictor.set_image(tissue_image)

        manual_prompt = np.array(self.prompt)  # manually select prompt
        tissue_masks, scores, logits = predictor.predict(
            point_labels=np.full(manual_prompt.shape[0], 1),
            point_coords=manual_prompt,
            multimask_output=True
        )
        tissue_masks = np.transpose(tissue_masks, (1, 2, 0)).astype(np.uint8)
        tissue_masks = cv2.cvtColor(tissue_masks, cv2.COLOR_BGR2GRAY) * 255
        tissue_image = cv2.cvtColor(tissue_image, cv2.COLOR_BGR2GRAY)

        test_output = tissue_image.copy()
        test_output[tissue_masks == 0] = 0
        if self.bs_out:
            cv2.imwrite(os.path.join(self.bs_out, f'{self.tissue_name}_test.png'), test_output)

        # load chip image
        chip_image = np.zeros((self.tissue_bbox[2], self.tissue_bbox[3]), dtype=np.uint8)
        chip = self.barcodes_detail.to_numpy()
        chip_contours = np.array([np.min(chip[:, 0]), np.max(chip[:, 0]), np.min(chip[:, 1]), np.max(chip[:, 1])])
        chip_masks = np.zeros_like(chip_image)
        chip_masks[chip_contours[2]: chip_contours[3], chip_contours[0]: chip_contours[1]] = 255

        row_coords, col_coords = np.where(tissue_masks == 255)
        min_row, max_row = np.min(row_coords), np.max(row_coords)
        min_col, max_col = np.min(col_coords), np.max(col_coords)
        bbox_tissue = [min_col, min_row, max_col, max_row]
        bbox_tissue = np.array(
            [[bbox_tissue[0], bbox_tissue[1]],
             [bbox_tissue[2], bbox_tissue[1]],
             [bbox_tissue[2], bbox_tissue[3]],
             [bbox_tissue[0], bbox_tissue[3]]]
        )
        bbox_chip = np.array(
            [[chip_contours[0], chip_contours[2]],
             [chip_contours[1], chip_contours[2]],
             [chip_contours[1], chip_contours[3]],
             [chip_contours[0], chip_contours[3]]]
        )

        # option: ‘similarity’ or ‘affine’ or ‘projective’
        tform = estimate_transform('affine', bbox_tissue, bbox_chip)
        H = tform.params
        tissue_image = test_output
        tissue_image = cv2.warpPerspective(tissue_image, H, (chip_image.shape[1], chip_image.shape[0]))

        # scanpy image for visualization
        scanpy_image = tissue_image.copy()
        scanpy_image_600 = cv2.resize(scanpy_image, (600, 600), interpolation=cv2.INTER_LANCZOS4)
        scanpy_image_2000 = cv2.resize(scanpy_image, (2000, 2000), interpolation=cv2.INTER_LANCZOS4)

        self.tissue_image = tissue_image

        torch.cuda.empty_cache()  # release gpu memory after registration
        if self.bs_out:
            tifffile.imwrite(os.path.join(self.bs_out, f'{self.tissue_name}_regist.tif'), tissue_image)
        tifffile.imwrite(os.path.join(self.exp_bin_im, f'{self.tissue_name}_regist.tif'), tissue_image)
        cv2.imwrite(os.path.join(self.exp_bin_im, f'tissue_lowres_image.png'), scanpy_image_600)
        cv2.imwrite(os.path.join(self.exp_bin_im, f'tissue_hires_image.png'), scanpy_image_2000)

    @utils.add_log
    def slice_registration(self, model, method="image"):
        resolution = np.ceil(10 / self.pixel_size).astype(int)
        if method == "gene_expr":
            self.gem_registration(resolution=resolution)
            self.he_registration(self.args.tif)
        elif method == "image":
            self.chipset_registration(model=model)
        self.save_register_image()

    @utils.add_log
    def chipset_registration(self, model, image_size=224):
        # image-segmentation base on transformer-unet framework
        self.chipset_segmentation(model, image_size=image_size)

        # load chip image
        chip_masks = np.zeros_like(self.tissue_image)
        positions = self.barcodes_detail.to_numpy()
        chip_contours = np.array([
            np.min(positions[:, 0]), np.max(positions[:, 0]), np.min(positions[:, 1]), np.max(positions[:, 1])
        ])
        chip_masks[chip_contours[2]: chip_contours[3], chip_contours[0]: chip_contours[1]] = 255

        row_coords, col_coords = np.where(self.pred == 1)
        min_col, min_row, max_col, max_row = np.min(col_coords), np.min(row_coords), np.max(col_coords), np.max(row_coords)
        bbox_tissue = [min_col, min_row, max_col, max_row]
        bbox_tissue = np.array(
            [[bbox_tissue[0], bbox_tissue[1]],
             [bbox_tissue[2], bbox_tissue[1]],
             [bbox_tissue[2], bbox_tissue[3]],
             [bbox_tissue[0], bbox_tissue[3]]]
        )
        bbox_chip = np.array(
            [[chip_contours[0], chip_contours[2]],
             [chip_contours[1], chip_contours[2]],
             [chip_contours[1], chip_contours[3]],
             [chip_contours[0], chip_contours[3]]]
        )

        # option: ‘similarity’ or ‘affine’ or ‘projective’
        tform = estimate_transform('affine', bbox_tissue, bbox_chip)
        H = tform.params
        tissue_image = self.tissue_image
        tissue_image = cv2.warpPerspective(tissue_image, H, (self.tissue_bbox[3], self.tissue_bbox[2]))
        self.tissue_image = tissue_image  # update tissue image after registration

    @utils.add_log
    def chipset_segmentation(self, model_path, image_size):
        im_chip_cut = self.tissue_image.copy()
        chip_cut = SwinChipCut(image_size=image_size, model_path=model_path)
        self.pred = chip_cut.f_predict(self.tissue_image)

        im_chip_cut[self.pred == 0] = 0
        self.tissue_image = im_chip_cut
        if self.bs_out:
            cv2.imwrite(os.path.join(self.bs_out, f'{self.tissue_name}_chip_cut.png'), im_chip_cut)

    def umi_bin_counts(self, counts_path, resolution):
        counts = pd.read_csv(counts_path, sep='\t', dtype={'Barcode': str,
                                                           'readcount': int,
                                                           'UMI2': int,
                                                           'UMI': int,
                                                           'geneID': int,
                                                           'mark': str})
        barcodes = self.barcodes_detail.copy()
        barcodes.columns = ['pxl_col_in_fullres', 'pxl_row_in_fullres', 'barcode']
        counts = counts.merge(barcodes, left_on='Barcode', right_on='barcode', how='inner')
        counts = counts.drop(columns=['barcode'])

        row_bins = np.arange(0, self.tissue_bbox[2] + resolution, resolution)
        col_bins = np.arange(0, self.tissue_bbox[3] + resolution, resolution)
        counts['row_bin'] = pd.cut(counts['pxl_row_in_fullres'], row_bins, labels=False, include_lowest=True, right=False)
        counts['col_bin'] = pd.cut(counts['pxl_col_in_fullres'], col_bins, labels=False, include_lowest=True, right=False)

        # get gem image
        num_bits = int(2 * np.ceil(np.ceil(np.log2(len(row_bins) * len(col_bins))) / 2))
        uuid = counts['row_bin'].values * len(col_bins) + counts['col_bin'].values
        uuid_binary = ((uuid[:, np.newaxis] & (1 << np.arange(num_bits))) > 0).astype(int)
        unicode = self.base_mapping[uuid_binary[:, ::-1].reshape(-1, 2).dot(np.array([2, 1]))]
        unicode = unicode.reshape(-1, num_bits // 2).view('U' + str(num_bits // 2)).ravel()
        counts['unicode'] = unicode

        counts = counts[['unicode', 'row_bin', 'col_bin', 'UMI']]
        counts = counts.rename(columns={'unicode': 'Barcode'})
        return counts, len(row_bins) - 1, len(col_bins) - 1

    @utils.add_log
    def gem_registration(self, resolution):
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        umi_counts, rows, cols = self.umi_bin_counts(self.counts_path, resolution)
        umi_counts = umi_counts.groupby(['Barcode', 'row_bin', 'col_bin']).agg({'UMI': 'sum'}).reset_index()
        self.gem = np.zeros((rows, cols), dtype=np.int64)
        self.gem[umi_counts['row_bin'].values, umi_counts['col_bin'].values] = umi_counts['UMI'].values

        if np.any(self.gem < 0):
            raise ValueError("GEM data contains negative values, which are not supported by threshold_multiotsu")

        thresholds = threshold_multiotsu(self.gem, classes=3)
        self.gem_mask = self.gem >= thresholds[0]
        self.gem_mask = skimage.morphology.remove_small_objects(self.gem_mask, min_size=2).astype(np.uint8) * 255
        self.gem_mask = cv2.morphologyEx(self.gem_mask, cv2.MORPH_CLOSE, kernel, iterations=3)
        self.gem_mask = skimage.morphology.remove_small_objects(self.gem_mask > 0, min_size=10).astype(np.uint8) * 255
        self.gem_mask = cv2.dilate(self.gem_mask, kernel, iterations=7)
        self.gem_mask = cv2.morphologyEx(self.gem_mask, cv2.MORPH_CLOSE, kernel, iterations=5)
        self.gem_mask = utils.hole_fill(self.gem_mask)
        self.gem_mask = cv2.erode(self.gem_mask, kernel, iterations=3)
        self.gem_mask = cv2.resize(self.gem_mask, (self.tissue_bbox[3], self.tissue_bbox[2]), interpolation=cv2.INTER_AREA)

        self.gem = utils.convert_8bit(self.gem)
        self.gem = cv2.resize(self.gem, (self.tissue_bbox[3], self.tissue_bbox[2]), interpolation=cv2.INTER_AREA)

    @utils.add_log
    def he_registration(self, tif_path):
        if tif_path and os.path.exists(tif_path):
            self.get_tissue_image(tif_path, resize=True)
        else:
            self.tissue_image = self.gem
            self.he_image_mask = self.gem_mask

        if self.rectify:
            processor = Processor(output=self.exp_bin_im, image=self.he_image)
            # roi_mask = processor.detect_border(border_value=179, tolerance=5, debug=False)
            roi_mask, _ = processor.detect_polygons(border_value=179, tolerance=5, min_area=100)
            degree, slope, center = processor.find_top_line(roi_mask)

            self.tissue_image, new_center = processor.get_rotate_image(self.tissue_image, degree, center)
            self.he_image_mask, new_center = processor.get_rotate_image(roi_mask, degree, center)

            points = self.barcodes_detail[["x", "y"]].values
            rotated_points = processor.rotate_points(points, -degree, new_center).astype(np.int32)
            min_x, min_y = rotated_points.min(axis=0)
            # max_x, max_y = rotated_points.max(axis=0)
            dx = np.abs(min_x) if min_x < 0 else 0
            dy = np.abs(min_y) if min_y < 0 else 0
            offset = np.array([dx, dy])
            rotated_points += offset
            self.barcodes_detail[["x", "y"]] = rotated_points

            motion_m = np.float32([[1, 0, dx], [0, 1, dy]])
            self.tissue_image = cv2.warpAffine(self.tissue_image, motion_m, (self.tissue_image.shape[1] + dx, self.tissue_image.shape[0] + dy))
            self.he_image_mask = cv2.warpAffine(self.he_image_mask, motion_m, (self.he_image_mask.shape[1] + dx, self.he_image_mask.shape[0] + dy))
            self.roi_rect = processor.get_nonzero_bbox(self.he_image_mask)

    @staticmethod
    def register_mask_images_sitk(image_fixed, image_moving):
        fixed_image = sitk.GetImageFromArray(image_fixed.astype(np.float32))
        moving_image = sitk.GetImageFromArray(image_moving.astype(np.float32))
        registration_method = sitk.ImageRegistrationMethod()
        registration_method.SetMetricAsMeanSquares()
        registration_method.SetInterpolator(sitk.sitkNearestNeighbor)
        registration_method.SetOptimizerAsRegularStepGradientDescent(1.0, 0.001, 200)
        initial_transform = sitk.CenteredTransformInitializer(fixed_image,
                                                              moving_image,
                                                              sitk.AffineTransform(fixed_image.GetDimension()),
                                                              sitk.CenteredTransformInitializerFilter.GEOMETRY)
        registration_method.SetInitialTransform(initial_transform)
        final_transform = registration_method.Execute(fixed_image, moving_image)
        moving_resampled = sitk.Resample(moving_image, fixed_image, final_transform,
                                         sitk.sitkNearestNeighbor, 0.0, moving_image.GetPixelID())
        result_mask = sitk.GetArrayFromImage(moving_resampled).astype(np.uint8)
        matrix = final_transform.GetMatrix()
        translation = final_transform.GetTranslation()
        transM = np.array([
            [matrix[0], matrix[1], translation[0]],
            [matrix[2], matrix[3], translation[1]]
        ])
        return result_mask, transM

    @staticmethod
    def contours_registration(image_fixed, image_moving):
        def get_contour_features(contour):
            # calculate moments of the contour
            M = cv2.moments(contour)
            # calculate the centroid
            cx = int(M['m10'] / M['m00'])
            cy = int(M['m01'] / M['m00'])
            # calculate the angle of the contour
            # (x, y), (MA, ma), angle = cv2.fitEllipse(contour)
            (x, y), (MA, ma), angle = cv2.fitEllipseAMS(contour)
            return (cx, cy), angle

        contours_fixed, _ = cv2.findContours(image_fixed, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        contours_moving, _ = cv2.findContours(image_moving, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        contour_fixed = contours_fixed[0]
        contour_moving = contours_moving[0]
        center_fixed, angle_fixed = get_contour_features(contour_fixed)
        center_moving, angle_moving = get_contour_features(contour_moving)

        rotation_angle = -(angle_fixed - angle_moving)

        area_fixed = cv2.contourArea(contour_fixed)
        area_moving = cv2.contourArea(contour_moving)
        scale = np.sqrt(area_fixed / area_moving)

        tx = center_fixed[0] - center_moving[0]
        ty = center_fixed[1] - center_moving[1]

        transform_matrix = cv2.getRotationMatrix2D(center_moving, rotation_angle, scale)
        transform_matrix[0, 2] += tx
        transform_matrix[1, 2] += ty
        return transform_matrix

    @utils.add_log
    def splitplot_experiment(self, seg_type, method):
        if seg_type == 'tissue':
            self.tissue_segmentation(method)
        elif seg_type == 'cell':
            self.cell_segmentation()  # future work

    @utils.add_log
    def tissue_segmentation(self, method="image"):
        def getArea(elem):
            return elem.area

        if method == "image":
            # tissue threshold segmentation
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (20, 20))
            _, tissue_mask = cv2.threshold(self.tissue_image, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
            tissue_mask = cv2.morphologyEx(tissue_mask, cv2.MORPH_CLOSE, kernel, iterations=8)

            # choose tissue prop
            label_image = measure.label(tissue_mask, connectivity=2)
            props = measure.regionprops(label_image, intensity_image=tissue_mask)
            props.sort(key=getArea, reverse=True)

            areas = [p['area'] for p in props]
            label_num = len(areas) if np.std(areas) * 10 < np.mean(areas) else int(np.sum(areas >= np.mean(areas)))

            result = np.zeros_like(self.tissue_image).astype(np.uint8)
            for i in range(label_num):
                prop = props[i]
                result += np.where(label_image != prop.label, 0, 1).astype(np.uint8)

            # find seed point for flood fill
            tissue_result = utils.hole_fill(result)
            # tissue_result = cv2.dilate(tissue_result, kernel, iterations=10)  # use it cautiously!👈
            self.tissue_image_mask = tissue_result
        elif method == "gene_expr":
            self.tissue_image_mask = self.he_image_mask

        if self.bs_out:
            tifffile.imwrite(os.path.join(self.bs_out, f'{self.tissue_name}_tissue_cut.tif'), self.tissue_image_mask)
        tifffile.imwrite(os.path.join(self.exp_bin_im, f'{self.tissue_name}_tissue_cut.tif'), self.tissue_image_mask)

    @utils.add_log
    def cell_segmentation(self):
        """
        discussion: sooner we may use cellpose-3.0 to implement cell segmentation
        """
        pass

    @staticmethod
    def get_offset(image):
        def get_boundary_point(image):
            mask = image.copy()
            mask[image != 0] = 255
            mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=5)

            boundary_points = []
            contours, hierarchy = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            contours = sorted(contours, key=cv2.contourArea, reverse=True)[:4]
            for contour in contours:
                # use Douglas-Peucker algorithm to approximate the contour
                epsilon = 0.009 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)
                # if the approximated contour has four(or more) points, then assume that screen is found
                # make sure it is a square at least
                if len(approx) >= 4:
                    boundary_points.extend(approx)

            return boundary_points

        boundary_points = get_boundary_point(image)
        boundary_points = np.array(boundary_points)
        left_top_index = np.linalg.norm(boundary_points - np.array([0, 0]), axis=2).argmin()
        transform_dis = (boundary_points[left_top_index].squeeze() - 100).clip(min=0)
        return transform_dis.astype(np.int32)

    @utils.add_log
    def generate_tissue_barcode_position(self):
        bcd = self.barcodes_detail.to_numpy()
        locs = bcd[:, :2].astype(int)

        # write tissue barcode position
        in_tissue = np.where(self.segment, np.where(self.tissue_image_mask[locs[:, 1], locs[:, 0]] == 255, 1, 0), 1)
        fi_bc = pd.DataFrame({
            'barcode': bcd[:, 2],
            'in_tissue': in_tissue,
            'array_row': None,
            'array_col': None,
            'pxl_row_in_fullres': bcd[:, 1],
            'pxl_col_in_fullres': bcd[:, 0],
        })
        fi_bc = fi_bc.sort_values(by=['pxl_row_in_fullres', 'pxl_col_in_fullres']).reset_index(drop=True)
        fi_bc = fi_bc[['barcode', 'in_tissue', 'array_row', 'array_col', 'pxl_row_in_fullres', 'pxl_col_in_fullres']]
        fi_bc.to_csv(os.path.join(self.exp_bs_path, f'{self.tissue_name}_Barcodes_tissue_positions.csv'), index=False)
        self.tb_position = fi_bc

    @utils.add_log
    def generate_count_detail(self):
        barcode_columns = ['barcode', 'pxl_row_in_fullres', 'pxl_col_in_fullres']
        self.in_bc = self.tb_position.loc[self.tb_position['in_tissue'] == 1].reset_index(drop=True)

        if self.rectify:
            dx, dy = self.roi_rect[:2]
            self.in_bc["pxl_col_in_fullres"] -= dx
            self.in_bc["pxl_row_in_fullres"] -= dy
            self.in_bc["pxl_col_in_fullres"] = self.in_bc["pxl_col_in_fullres"].clip(0, self.slice_px - 1)
            self.in_bc["pxl_row_in_fullres"] = self.in_bc["pxl_row_in_fullres"].clip(0, self.slice_px - 1)

            self.tissue_image = self.tissue_image[self.roi_rect[1]: self.roi_rect[1] + self.roi_rect[3], self.roi_rect[0]: self.roi_rect[0] + self.roi_rect[2]]
            self.he_image_mask = self.he_image_mask[self.roi_rect[1]: self.roi_rect[1] + self.roi_rect[3], self.roi_rect[0]: self.roi_rect[0] + self.roi_rect[2]]
            self.tissue_image = cv2.resize(self.tissue_image, (self.slice_px, self.slice_px))
            self.he_image_mask = cv2.resize(self.he_image_mask, (self.slice_px, self.slice_px))
            self.he_image_mask[self.he_image_mask > 0] = 255

            self.save_register_image(is_correct=True)

        self.gene_count_detail = pd.read_csv(self.count_detail, sep='\t', dtype={'Barcode': str, 'geneID': str, 'UMI': str, 'count': str})
        self.gene_count_detail = self.gene_count_detail.merge(self.in_bc[barcode_columns], left_on='Barcode', right_on='barcode', how='inner')
        self.gene_count_detail = self.gene_count_detail.drop(columns=['barcode'])
        if self._raw_show:
            self.raw_count_detail = self.gene_count_detail.copy(deep=True)
            self.raw_count_detail = self.raw_count_detail.rename(columns={'Barcode': 'unicode'})
            self.raw_count_detail = self.raw_count_detail.rename(columns={'pxl_row_in_fullres': 'row_in_bin'})
            self.raw_count_detail = self.raw_count_detail.rename(columns={'pxl_col_in_fullres': 'col_in_bin'})

    @utils.add_log
    def spatial_bin_generate(self):
        mask_shape = self.tissue_image_mask.shape
        bin_args = [[i, SquareBin(
            self._micron_bin[i], self.bin[i], [0, 0, mask_shape[1], mask_shape[0]],
            bin_folder=os.path.join(self.exp_sq_bin, f'{self.tissue_name}_bin{self._micron_bin[i]}'),
            gene_count_detail=self.gene_count_detail.copy(deep=True))] for i in range(len(self._micron_bin))
        ]
        if self._raw_show:
            bin_args.append(
                [None, SquareBin('Raw', self._bin, [0, 0, mask_shape[1], mask_shape[0]],
                                 bin_folder=os.path.join(self.exp_sq_bin, f'{self.tissue_name}_Raw'),
                                 gene_count_detail=self.raw_count_detail)]
            )
        if not self._parallel:
            for args in bin_args:
                self.bin_files_execute(args)
        else:
            Parallel(n_jobs=len(self._micron_bin))(map(delayed(self.bin_files_execute), bin_args))
        self.bin_exec = bin_args

        del self.gene_count_detail  # release memory after bin segment
        del self.raw_count_detail

    @utils.add_log
    def bin_files_execute(self, args):
        i, handler = args
        print(f"Bin {handler.micron_bin}.")

        is_raw = handler.micron_bin == 'Raw'
        if is_raw:
            gene = self.raw_count_detail
        elif isinstance(handler.micron_bin, int):
            self.bin_segment(handler)
            gene = handler.gene_count_detail
        else:
            raise ValueError("Please check the input parameters <bin>")

        unique_gene = self.unique_gene_count(gene)
        tissue_barcode = self.tissue_barcode_position(gene)

        self.gene_indicator_stats(handler, unique_gene, tissue_barcode)
        self.generate_gene_matrix(handler, unique_gene)

        base_dir = handler.bin_folder
        matrix_dir = os.path.join(base_dir, "filtered_feature_bc_matrix")
        spatial_dir = os.path.join(base_dir, "spatial")

        os.makedirs(matrix_dir, exist_ok=True)

        gene_tsv_path = os.path.join(handler.bin_folder, "matrix", "genes.tsv")
        print(f"Checking genes.tsv existence: {gene_tsv_path} -> exists: {os.path.exists(gene_tsv_path)}")
        if os.path.exists(gene_tsv_path):
            features_gz_path = os.path.join(matrix_dir, "features.tsv.gz")
            try:
                with open(gene_tsv_path, 'r') as f_in:
                    with gzip.open(features_gz_path, 'wt') as f_out:
                        for line in f_in:
                            f_out.write(line.strip() + "\tGene Expression\n")

                print(f"Generated features.tsv.gz at {features_gz_path}")
                os.remove(gene_tsv_path)
                print(f"Removed redundant genes.tsv at {gene_tsv_path}")
            except Exception as e:
                print(f"Error processing genes.tsv: {e}")

        for ext in ["barcodes.tsv", "features.tsv", "matrix.mtx"]:
            src_file = os.path.join(handler.bin_folder, "matrix", ext)
            dst_file = os.path.join(matrix_dir, ext)
            if os.path.exists(src_file):
                shutil.move(src_file, dst_file)
                os.system(f"gzip {dst_file}") 


        tissue_positions_list_path = os.path.join(spatial_dir, "tissue_positions_list.csv")
        tissue_barcode.to_csv(tissue_positions_list_path, header=True, index=False)
        print(f"Generated tissue_positions_list.csv at {tissue_positions_list_path}")

        hires_img = os.path.join(self.exp_bin_im, "tissue_hires_image.png")
        lowres_img = os.path.join(self.exp_bin_im, "tissue_lowres_image.png")
        if os.path.exists(hires_img):
            shutil.copy(hires_img, os.path.join(spatial_dir, "tissue_hires_image.png"))
        if os.path.exists(lowres_img):
            shutil.copy(lowres_img, os.path.join(spatial_dir, "tissue_lowres_image.png"))


        scalefactor_file = os.path.join(handler.bin_folder, "scalefactors_json.json")
        if os.path.exists(scalefactor_file):
            shutil.move(scalefactor_file, os.path.join(spatial_dir, "scalefactors_json.json"))

        try:
            self.scale_tissue_positions(spatial_dir)
        except Exception as e:
            print(f"[ERROR] tissue_positions: {e}")


        count_detail_file = os.path.join(handler.bin_folder,
                                         f"{self.tissue_name}_Bin{handler.micron_bin}_count_detail.txt")
        if os.path.exists(count_detail_file):
            shutil.move(count_detail_file, os.path.join(base_dir, "stat.txt"))
             # Clean up temporary matrix folder after processing
        matrix_temp_dir = os.path.join(handler.bin_folder, 'matrix')
        if os.path.exists(matrix_temp_dir):
            shutil.rmtree(matrix_temp_dir)
            print(f"Cleaned up temporary matrix folder: {matrix_temp_dir}")

    @utils.add_log
    def scale_tissue_positions(self, spatial_dir):
        coords_file = os.path.join(spatial_dir, "tissue_positions_list.csv")
        scalefactors_file = os.path.join(spatial_dir, "scalefactors_json.json")
        output_file = os.path.join(spatial_dir, "tissue_positions_scaled.csv")

        if not os.path.exists(coords_file):
            raise FileNotFoundError(f"The coords file was not found: {coords_file}")
        coords_data = pd.read_csv(coords_file)

        if not os.path.exists(scalefactors_file):
            raise FileNotFoundError(f"The scalefactors file was not found: {scalefactors_file}")
        with open(scalefactors_file) as f:
            scalefactors = json.load(f)
        hires_scalef = scalefactors["tissue_hires_scalef"]

        coords_data["pxl_row_in_fullres"] = coords_data["row_in_bin"] * hires_scalef
        coords_data["pxl_col_in_fullres"] = coords_data["col_in_bin"] * hires_scalef

        cols = ["Barcode", "in_tissue", "row_in_bin", "col_in_bin", "pxl_row_in_fullres", "pxl_col_in_fullres"]
        coords_data = coords_data[cols]
        coords_data.rename(columns={"Barcode": "barcode"}, inplace=True)

        coords_data.to_csv(output_file, index=False, header=False)

        if os.path.exists(coords_file):
            os.remove(coords_file)
        os.rename(output_file, coords_file)
        print(f"The original has been updated tissue_positions_list.csv: {coords_file}")


    def bin_segment(self, bin_handler):
        self.bs_mtx = bin_handler.upsampling_tissue_matrix()  # generate gene matrix
        up_row = bin_handler.up_row
        up_col = bin_handler.up_col
        bin = bin_handler.bin
        num_bits = bin_handler.num_bits

        # broadcast variables
        row_bins = np.arange(0, self.tissue_image_mask.shape[0] + bin, bin)
        col_bins = np.arange(0, self.tissue_image_mask.shape[1] + bin, bin)
        assert len(row_bins) == up_row + 1 and len(col_bins) == up_col + 1  # check bins

        bin_handler.gene_count_detail['row_in_bin'] = pd.cut(bin_handler.gene_count_detail['pxl_row_in_fullres'], bins=row_bins, labels=False, include_lowest=True, right=False)
        bin_handler.gene_count_detail['col_in_bin'] = pd.cut(bin_handler.gene_count_detail['pxl_col_in_fullres'], bins=col_bins, labels=False, include_lowest=True, right=False)
        unicode_values = bin_handler.gene_count_detail['row_in_bin'].values * up_col + bin_handler.gene_count_detail['col_in_bin'].values
        unicode_values_bi = np.zeros((len(unicode_values), num_bits), dtype=np.uint8)
        for i in range(num_bits):
            unicode_values_bi[:, i] = (unicode_values >> i) & 1
        unicode = self.base_mapping[unicode_values_bi[:, ::-1].reshape(-1, 2).dot(np.array([2, 1]))]
        unicode = unicode.reshape(-1, num_bits // 2).view('U' + str(num_bits // 2)).ravel()
        bin_handler.gene_count_detail['unicode'] = unicode

    @staticmethod
    def unique_gene_count(gene_detail):
        columns_extract = ['unicode', 'geneID', 'UMI', 'count']
        unique_gene_count_detail = gene_detail[columns_extract]
        unique_gene_count_detail = unique_gene_count_detail.rename(columns={'unicode': 'Barcode'})
        return unique_gene_count_detail

    @staticmethod
    def tissue_barcode_position(gene_detail):
        columns_extract = ['unicode', 'row_in_bin', 'col_in_bin']
        count_detail = gene_detail[columns_extract]
        count_detail = count_detail.rename(columns={'unicode': 'Barcode'})
        count_detail.insert(1, 'in_tissue', 1)
        count_detail = count_detail.drop_duplicates(subset=['Barcode'])
        return count_detail

    @staticmethod
    def gene_indicator_stats(bin_handler, count_detail, bin_position):
        def num_gt2(x):
            return (x > 1).sum()

        count_detail['count'] = count_detail['count'].astype(int)
        bin_count_detail = count_detail.groupby('Barcode').agg({
            'count': ['sum', num_gt2],
            'UMI': 'count',
            'geneID': 'nunique'
        })
        bin_count_detail.columns = ['readcount', 'UMI2', 'UMI', 'geneID']
        bin_count_detail.sort_values(by='UMI', ascending=False)

        estimated_cells = len(bin_position)
        total_genes = count_detail['geneID'].nunique()
        mean_reads_per_cell = int(bin_count_detail['readcount'].sum() / estimated_cells)
        median_reads_per_cell = int(bin_count_detail['readcount'].median())
        mean_umi_per_cell = int(bin_count_detail['UMI'].mean())
        median_umi_per_cell = int(bin_count_detail['UMI'].median())
        mean_genes_per_cell = int(bin_count_detail['geneID'].mean())
        median_genes_per_cell = int(bin_count_detail['geneID'].median())

        with open(os.path.join(bin_handler.bin_folder, f'stat.txt'), 'w') as f:
            f.write(f"Total Genes: {total_genes: ,.0f}\n")
            f.write(f"Estimated Number of square bin: {estimated_cells: ,.0f}\n")
            f.write(f"Mean Reads per square bin: {mean_reads_per_cell: ,.0f}\n")
            f.write(f"Median Reads per square bin: {median_reads_per_cell: ,.0f}\n")
            f.write(f"Mean UMI per square bin: {mean_umi_per_cell: ,.0f}\n")
            f.write(f"Median UMI per square bin: {median_umi_per_cell: ,.0f}\n")
            f.write(f"Mean Genes per square bin: {mean_genes_per_cell: ,.0f}\n")
            f.write(f"Median Genes per square bin: {median_genes_per_cell: ,.0f}\n")

    def get_bin_summary(self, use_raw=False):
        # get bin statistics
        def parse_stat_file(content):
            stats = {}
            for line in content.split('\n'):
                if ':' in line:
                    key, value = line.split(':', 1)
                    key = key.strip()
                    value = value.strip()
                    try:
                        value = float(value.replace(',', ''))
                        if value.is_integer():
                            value = int(value)
                    except ValueError:
                        pass
                    stats[key] = value
            return stats

        bin_statistics = {}
        if self.bin_exec is not None:
            for i, bh in self.bin_exec:
                if not use_raw and i is None:
                    continue
                if bh is not None:
                    with open(os.path.join(bh.bin_folder, f'stat.txt'), 'r') as f:
                        bin_statistics[bh.micron_bin] = parse_stat_file(f.read())

        if bin_statistics:
            table_plot = Table_plot(data=bin_statistics, index_name='Bin Size')
            table_plot.figure.write_html(os.path.join(self.outdir, 'bin_statistics.html'))
        else:
            table_plot = None
        self.add_data(table_plot=table_plot.to_dict()) if table_plot else self.add_data(table_plot=None)

    @staticmethod
    def get_gtf(genome_dir):
        gtf_file = Mkref_rna.parse_genomeDir(genome_dir)['gtf']
        gp = reference.GtfParser(gtf_file)
        gp.get_id_name()
        features = gp.get_features()
        return features

    def generate_gene_matrix(self, bin_handler, gene_count):
        matrix_dir = os.path.join(bin_handler.bin_folder, 'matrix')
        count_matrix = CountMatrix.from_dataframe(gene_count, self.features, value="UMI")
        utils.check_mkdir(dir_name=matrix_dir)
        count_matrix.get_features().to_tsv(os.path.join(matrix_dir, FEATURE_FILE_NAME))
        pd.Series(count_matrix.get_barcodes()).to_csv(os.path.join(matrix_dir, BARCODE_FILE_NAME),
                                                      index=False, sep='\t', header=False)
        matrix_path = os.path.join(matrix_dir, MATRIX_FILE_NAME)
        mmwrite(matrix_path, count_matrix.get_matrix())  # use scipy to write matrix file

    def gzip_bin_files(self, bin_handler):

        gzip_path = os.path.join(
            self.exp_tmp_path,
            f"{os.path.basename(bin_handler.bin_folder)}_{datetime.now().strftime('%Y%m%d%H%M')}.tar.gz"
        )
        with tarfile.open(gzip_path, 'w:gz') as tar:
            tar.add(bin_handler.bin_folder, arcname=os.path.basename(bin_handler.bin_folder))
    def _barcode_extend(self):
        ref = {}
        for bc in self._bc_list.to_numpy():
            bc = bc[0]  # trap here
            ref[bc[:4]] = bc
        for row, item in tqdm(self.barcodes_detail.iterrows(), desc='ex_barcode', total=self.barcodes_detail.shape[0]):
            barcode = item[2]
            cur_barcodes = ''.join([ref[barcode[4 * i: 4 * i + 4]] for i in range(len(barcode) // 4)
                                    if barcode[4 * i: 4 * i + 4] in reference])
            # only if barcode length is 18, then we can use it
            if len(cur_barcodes) == 18:
                self.barcodes_detail.at[row, 2] = cur_barcodes
        self.barcodes_detail = self.barcodes_detail[self.barcodes_detail[2].str.len() == 18]

    def test_get_bin_summary(self):
        self.bin_exec = [
            [i, SquareBin(self._micron_bin[i],
                            self.bin[i],
                            self.tissue_bbox,
                            bin_folder=os.path.join(self.exp_sq_bin,
                                                    f'{self.tissue_name}_bin{self._micron_bin[i]}')
                            )] for i in range(len(self._micron_bin))
        ]
        self.bin_exec.append(
            [None, SquareBin('Raw',
                               self._bin,
                               self.tissue_bbox,
                               bin_folder=os.path.join(self.exp_sq_bin, f'{self.tissue_name}_Raw')
                               )]
        )
        self.get_bin_summary()

    def get_tissue_image(self, tif_path, resize=True):
        self.he_image, _ = utils.read_tiff_with_metadata(tif_path)
        self.image_d = self.he_image.copy()
        if self.he_image.ndim == 3:
            self.he_image = cv2.cvtColor(self.he_image, cv2.COLOR_BGR2GRAY)
            self.he_image = cv2.bitwise_not(self.he_image)
            self.he_image = cv2.resize(self.he_image, None, fx=1/3, fy=1/3) if resize else self.he_image
            self.image_d = cv2.resize(self.image_d, None, fx=1/3, fy=1/3) if resize else self.image_d

        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        _, binary = cv2.threshold(self.he_image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=5)
        contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        if contours:
            max_contour = max(contours, key=cv2.contourArea)
            mask = np.zeros(self.he_image.shape[:2], dtype=np.uint8)
            cv2.drawContours(mask, [max_contour], 0, 255, -1)
            # filled_mask = hole_fill(mask)
            filled_mask = mask
        else:
            filled_mask = np.zeros(self.he_image.shape[:2], dtype=np.uint8)
        self.he_image_mask = filled_mask

        trans_matrix = self.contours_registration(self.gem_mask, self.he_image_mask)
        self.he_image = cv2.warpAffine(self.he_image, trans_matrix, (self.tissue_bbox[3], self.tissue_bbox[2]))
        self.he_image_mask = cv2.warpAffine(self.he_image_mask, trans_matrix,
                                            (self.tissue_bbox[3], self.tissue_bbox[2]))

        self.image_d = cv2.warpAffine(self.image_d, trans_matrix, (self.tissue_bbox[3], self.tissue_bbox[2]))
        self.image_d[self.he_image_mask == 0] = 0
        self.tissue_image = self.image_d

    @utils.add_log
    def save_register_image(self, is_correct=False):
        # scanpy image for visualization
        scanpy_image = self.tissue_image.copy()
        # shift = self.get_offset(scanpy_image)
        # transM = np.float32([[1, 0, -shift[0]], [0, 1, -shift[1]]])
        # scanpy_image = cv2.warpAffine(scanpy_image, transM, (scanpy_image.shape[1], scanpy_image.shape[0]))
        scanpy_image_600 = cv2.resize(scanpy_image, (600, 600))
        scanpy_image_2000 = cv2.resize(scanpy_image, (2000, 2000))

        if is_correct:
            fine_tune = np.float32([[1, 0, -self.bin[-1] // 2], [0, 1, -self.bin[-1] // 2]])
            scanpy_image_600 = cv2.warpAffine(scanpy_image_600, fine_tune, (600, 600))
            scanpy_image_2000 = cv2.warpAffine(scanpy_image_2000, fine_tune, (2000, 2000))

        if scanpy_image.ndim == 3:
            scanpy_image_600 = cv2.cvtColor(scanpy_image_600, cv2.COLOR_RGB2BGR)
            scanpy_image_2000 = cv2.cvtColor(scanpy_image_2000, cv2.COLOR_RGB2BGR)

        if self.bs_out:
            tifffile.imwrite(os.path.join(self.bs_out, f'{self.tissue_name}_regist.tif'), self.tissue_image)
        tifffile.imwrite(os.path.join(self.exp_bin_im, f'{self.tissue_name}_regist.tif'), self.tissue_image)
        cv2.imwrite(os.path.join(self.exp_bin_im, f'tissue_lowres_image.png'), scanpy_image_600)
        cv2.imwrite(os.path.join(self.exp_bin_im, f'tissue_hires_image.png'), scanpy_image_2000)

    @utils.add_log
    def clean_redundant_folders(self):
        """Clean redundant folders: matrix, images, tmp."""
        redundant_folders = [
            os.path.join(self.exp_bs_path, 'matrix'),
            os.path.join(self.exp_bs_path, 'tmp')
        ]

        for folder in redundant_folders:
            if os.path.exists(folder):
                shutil.rmtree(folder)
                self.clean_redundant_folders.logger.info(f"Deleted redundant folder: {folder}")
            else:
                self.clean_redundant_folders.logger.info(f"Folder does not exist: {folder}")


    @utils.add_log
    def clean_specific_folder(self):
        """Clean the specific folder named '{sample_name}_Bin[10, 20, 50, 100]'."""
        target_folder = os.path.join(self.exp_sq_bin, f"{self.tissue_name}_bin[10, 20, 50, 100]")
        if os.path.exists(target_folder):
            shutil.rmtree(target_folder)
            self.clean_specific_folder.logger.info(f"Deleted specific folder: {target_folder}")
        else:
            self.clean_specific_folder.logger.info(f"Specific folder does not exist: {target_folder}")

    @utils.add_log
    def run(self):
        self.prepare()
        if self.segment:
            self.slice_registration(self.model, self.method)
            self.splitplot_experiment(self.segment_type, self.method)
        if self.count:
            self.features = self.get_gtf(self.ref_genome)
            if self.segment_type == 'tissue':
                self.generate_tissue_barcode_position()
                self.generate_count_detail()
                self.spatial_bin_generate()
            elif self.segment_type == 'cell':
                pass
        self.get_bin_summary()

        barcode_csv = os.path.join(self.exp_bs_path, f"{self.tissue_name}_Barcodes_tissue_positions.csv")
        target_csv = os.path.join(os.path.dirname(self.exp_bs_path),
                                  f"{self.tissue_name}_Barcodes_tissue_positions.csv")
        if os.path.exists(barcode_csv):
            shutil.move(barcode_csv, target_csv)

        bin_size = self._micron_bin
        bin_folder = os.path.join(self.exp_sq_bin, f"{self.tissue_name}_bin{bin_size}")
        spatial_dir = os.path.join(bin_folder, 'spatial')
        tissue_positions_path = os.path.join(spatial_dir, 'tissue_positions.csv')

        os.makedirs(spatial_dir, exist_ok=True)

        if list(self.barcodes_detail.columns) != ['barcode', 'x', 'y']:
            self.barcodes_detail.columns = ['barcode', 'x', 'y']

        self.barcodes_detail.to_csv(tissue_positions_path, index=False)
        print(f"Generated tissue_positions.csv at {tissue_positions_path}")

        self.clean_redundant_folders()
        self.clean_specific_folder()


@utils.add_log
def validate_parameters(args):
    # if not args.sample.startswith("ST") and not args.sample.startswith("OST"):
    #     raise ValueError('--sample must start with "ST" or "OST"')
    if args.rectify:
        assert os.path.exists(args.tif), "HE image is required for rectification! Please check the path."
    if args.segment:
        segment_required_args = ['input', 'outdir', 'model']
        segment_required_args.append('tif') if args.method == 'image' else None
        if not all(getattr(args, arg, None) for arg in segment_required_args):
            missing_args = [arg for arg in segment_required_args if not getattr(args, arg, None)]
            raise ValueError(f'The following arguments are required when using --segment: {", ".join(missing_args)} '
                             f'(method: {args.method})')
        else:
            if args.tif and not os.path.exists(args.tif) and args.method == 'image':
                raise FileNotFoundError(f"tif file {args.tif} not found, please check it again")
            if args.model and not os.path.exists(args.model):
                raise FileNotFoundError(f"model file {args.model} not found, please check it again")
    if args.count:
        count_required_args = ['input', 'outdir', 'count_detail', 'genomeDir']
        if not all(getattr(args, arg, None) for arg in count_required_args):
            missing_args = [arg for arg in count_required_args if not getattr(args, arg, None)]
            raise ValueError(f'These arguments are required when using --count: {", ".join(missing_args)}')
        else:
            if not os.path.exists(args.count_detail):
                raise FileNotFoundError(f"count detail file {args.count_detail} not found, please check it again")
            if not os.path.exists(args.genomeDir):
                raise FileNotFoundError(f"genomeDir file {args.genomeDir} not found, please check it again")

    standing_parameters = {
        'sample': args.sample,
        'input': args.input,
        'outdir': args.outdir,
        'model': args.model,
        'prompt': args.prompt,
        'pixel_size': args.pixel_size,
        'genomeDir': args.genomeDir,
        'tif': args.tif,
        'count_detail': args.count_detail,
        'segment': args.segment,
        'count': args.count,
        'extend': args.extend,
    }

    sample = standing_parameters['sample']
    gene_type = standing_parameters['genomeDir']
    count_detail = standing_parameters['count_detail']
    pixel_size = standing_parameters['pixel_size']

    if args.count:
        if sample not in count_detail:
            raise ValueError(f"sample {sample} not fit in count detail path, check it again")
    if pixel_size <= 0:
        raise ValueError(f"pixel size {pixel_size} is invalid, please check it again")
    if isinstance(gene_type, list):
        if gene_type[0] not in genome:
            raise ValueError(f"reference genome {gene_type[0]} not found, please check it again")
    print("these parameters are valid.")

@utils.add_log
def binSegment(args):
    validate_parameters(args)
    with BinSegment(args, display_title="SquareBin") as runner:
        runner.run()
        # runner.test_get_bin_summary()

def get_opts_binSegment(parser, sub_program):
    parser.add_argument(
        '--input',
        help='data(Barcodes & Bbox) path of the current sample',
        type=str
    )
    parser.add_argument(
        '--model',
        help='image segmentation model path',
        type=str
    )
    parser.add_argument(
        '--segment-type',
        help='run segmentation mode, tissue or cell',
        type=str,
        default='tissue'
    )
    parser.add_argument(
        '--method',
        help='image segmentation method',
        type=str,
        default='gene_expr'
    )
    parser.add_argument(
        '--pixel-size',
        help='Each pixel corresponds to a certain number of micrometers.',
        type=float,

    )
    parser.add_argument(
        '--prompt',
        help="""The coordinates of the positions anchored on the chip are utilized for vision transformer model segmentation.
The coordinates are manually selected. (This argument is deprecated and will be removed in future versions)""",
        type=str,
    )
    parser.add_argument(
        '--tif',
        help='Fluorescence Tissue Imaging under Optical Microscopy',
        type=str,
    )
    parser.add_argument(
        '--genomeDir',
        help=HELP_DICT['genomeDir'],
    )
    parser.add_argument(
        '--count_detail',
        help="""The detailed information of barcode counts, including the sequence of each barcode, gene ID, UMI, and count, 
will be used for data integration this step.""",
        type=str,
    )
    parser.add_argument(
        '--bs_out',
        help="""We specify this folder to store images segmented by the our pre-trained segmentation model, 
in order to check the segmentation effect. If not specified, the default folder is the same as the output folder.
If the parameter bs_out is correctly set, a folder named 'binSegment' will be automatically created 
at the corresponding path.""",
        type=str,
        default=None
    )
    if sub_program:
        parser.add_argument('--segment', action='store_true', help='segment tissue image by pre-trained model')
        parser.add_argument('--count', action='store_true', help='count of in-tissue image')
        parser.add_argument('--rectify', action='store_true', help='whether to rectify the tissue by the HE image roi')
        parser.add_argument('--extend', action='store_true', help='extend barcode from 12 to 18 (deprecated)')
        parser = s_common(parser)
    return parser

def main():
    parser = argparse.ArgumentParser(description='Celatlas Spatial', formatter_class=ArgFormatter)
    parser.add_argument('-v', '--version', action='version', version=__VERSION__)
    subparsers = parser.add_subparsers(dest='subparser_assay')
    subparser_1st = subparsers.add_parser('rna')
    subparser_2nd = subparser_1st.add_subparsers()
    subparser_bin_segment = subparser_2nd.add_parser('binSegment_analysis', formatter_class=ArgFormatter)
    subparser_bin_segment.add_argument('--model', type=str, default='/home/zhoumy/lizt/code/work_space/spatial_bin/swin_tiny.pth', help='path to model')
    subparser_bin_segment.add_argument('--thread', type=int, default=8, help='number of threads')
    subparser_bin_segment.add_argument('--pixel-size', type=float, default=0.5, help='pixel size of microscope image')
    subparser_bin_segment.add_argument('--sample', type=str, default='OST110014', help='tissue name')
    subparser_bin_segment.add_argument('--prompt', type=str, default='[[5168,2928],[6384,4416]]', help='tissue position prompt')
    subparser_bin_segment.add_argument('--genomeDir', type=str, default='/mnt/strna/work_project/rawdata/celatlas_spatial/reference/Mus_musculus', help='reference genome type')
    subparser_bin_segment.add_argument('--input', type=str, default='/mnt/chip_mapping/', help='path to chip mapping')
    subparser_bin_segment.add_argument('--outdir', type=str, default='/mnt/strna/work_project/pipeline/celatlas_spatial/OST110014/06.binSegment', help='output path')
    subparser_bin_segment.add_argument('--bs_out', type=str, default='/mnt/strna/work_project/rawdata/stomics/binSegment/', help='path to binSegment')
    # subparser_bin_segment.add_argument('--tif', type=str, default='/mnt/strna/work_project/rawdata/celatlas_spatial/images/ST110121_C1.tif', help='tissue microscope image path')
    subparser_bin_segment.add_argument('--tif', type=str, default='/mnt/strna/work_project/rawdata/stomics/binSegment/STProtein_test/protein_label_region.tif', help='tissue microscope image path')
    subparser_bin_segment.add_argument('--count_detail', type=str, default='/mnt/strna/work_project/pipeline/celatlas_spatial/OST110014/05.count/OST110014_count_detail.txt', help='reads path')
    subparser_bin_segment.add_argument('--segment-type', type=str, default='tissue', help='run segmentation mode, tissue or cell')
    subparser_bin_segment.add_argument('--method', type=str, default='gene_expr', help='image segmentation method')
    subparser_bin_segment.add_argument('--rectify', action='store_true', help='rectify tissue image by HE image roi')
    subparser_bin_segment.add_argument('--segment', action='store_true', help='segment tissue image')
    subparser_bin_segment.add_argument('--count', action='store_true', help='gene count')
    subparser_bin_segment.add_argument('--extend', action='store_true', help='extend barcode from 12 to 18')
    subparser_bin_segment.add_argument('--debug', action='store_true', help='debug mode')
    subparser_bin_segment.add_argument('--omics', type=str, default='rna', help='omics type')
    args = parser.parse_args()

    args.segment = True  # image segmentation test
    args.count = True  # count test
    args.rectify = False  # rectify test
    args.subparser_assay = 'rna'
    args.tif = None

    binSegment(args)  # process tissue count


if __name__ == '__main__':
    main()
