#!/bin/bash
set -e

# =========================
# Celatlas Spatial Reanalysis Script (Optimized)
# =========================
# Purpose: Re-run spatial analysis from binSegment step (06.binSegment)
# Use case: When steps 00-05 are complete but you need to rerun binSegment and analysis
# Supports: HE, image, gene_expr modes

# # =========================
# # Environment Activation
# # =========================
# if [[ -f "$HOME/anaconda3/etc/profile.d/conda.sh" ]]; then
#     source "$HOME/anaconda3/etc/profile.d/conda.sh"
# else
#     echo "ERROR: Conda not found at $HOME/anaconda3"
#     exit 1
# fi

# conda activate celatlas_spatial17 || {
#     echo "ERROR: Failed to activate environment 'celatlas_spatial17'"
#     exit 1
# }

# =========================
# OpenBLAS Thread Limit
# =========================
# Set to 32 for good performance while staying within OpenBLAS compiled limit (~64)
# For bin10, t-SNE will be skipped automatically to avoid segfault
export OPENBLAS_NUM_THREADS=32
export OMP_NUM_THREADS=32
export MKL_NUM_THREADS=32
export VECLIB_MAXIMUM_THREADS=32
export NUMEXPR_NUM_THREADS=32

# =========================
# Helpers
# =========================
run_command() {
  echo "Running:" "$@"
  "$@"
  if [ $? -ne 0 ]; then
    echo "Error: Command failed: $@"
    exit 1
  fi
}

# =========================
# Input Parameters
# =========================
positional_args=()
OPT_CHIP_FORMAT=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --chip-format)
            if [[ $# -lt 2 || "$2" == -* ]]; then
                echo "Error: --chip-format requires a value: auto, 15x3, wide, bbox, or legacy."
                exit 1
            fi
            OPT_CHIP_FORMAT="$2"
            shift 2
            ;;
        -*)
            echo "Error: Unknown option '$1'"
            echo "Run '$0' without arguments for usage information."
            exit 1
            ;;
        *)
            positional_args+=("$1")
            shift
            ;;
    esac
done

set -- "${positional_args[@]}"

if [ $# -eq 7 ]; then
    sample_name="$1"
    chip_number="$2"
    casno="$3"
    chemistry="$4"
    Species="$5"
    method="$6"      # image | gene_expr | HE
    mode="$7"        # scrna | strna
    sample="$chip_number"
elif [ $# -eq 6 ]; then
    sample_name=""
    chip_number="$1"
    casno="$2"
    chemistry="$3"
    Species="$4"
    method="$5"
    mode="$6"
    sample="$chip_number"
else
    echo "====================================================================="
    echo "Celatlas Reanalysis Script - Rerun Analysis & Report Generation"
    echo "====================================================================="
    echo ""
    echo "USAGE:"
    echo "  $0 <sample_name> <chip_number> <casno> <chemistry> <Species> <method> <mode>"
    echo "  $0 <chip_number> <casno> <chemistry> <Species> <method> <mode>"
    echo ""
    echo "PARAMETERS:"
    echo "  sample_name  - Sample name (optional)"
    echo "  chip_number  - Chip number"
    echo "  casno        - Case number (e.g., test_1210)"
    echo "  chemistry    - Chemistry type (e.g., BBV2.4)"
    echo "  Species      - Species name (e.g., Mus_musculus, Homo_sapiens)"
    echo "  method       - Processing method: 'image', 'ssDNA', 'gene_expr', or 'HE'"
    echo "  mode         - Analysis mode: 'scrna' or 'strna'"
    echo ""
    echo "OPTIONS:"
    echo "  --chip-format <format>  Chip coordinate format for binSegment"
    echo "                          Options: auto, 15x3, wide, bbox, legacy"
    echo "                          Default: auto"
    echo ""
    echo "WHAT THIS SCRIPT DOES:"
    echo "  Spatial mode (strna):"
    echo "    - Reruns 06.binSegment (spatial binning)"
    echo "    - Reruns 07.analysis (spatial analysis)"
    echo "    - Regenerates HTML report"
    echo ""
    echo "  scRNA mode (scrna):"
    echo "    - Reruns 06_analysis_wrapper (QC + UMAP)"
    echo "    - Regenerates HTML report"
    echo ""
    echo "PREREQUISITES:"
    echo "  - Steps 01-05 must be completed successfully"
    echo "  - For spatial: count data in 05.count/"
    echo "  - For scRNA: filtered matrix in 05.count/*_filtered_feature_bc_matrix/"
    echo ""
    echo "EXAMPLES:"
    echo "  # Spatial mode (HE)"
    echo "  $0 ST110250_A1 test_1210 BBV2.4 Mus_musculus HE strna"
    echo ""
    echo "  # Spatial mode (gene expression)"
    echo "  $0 test_1210 BBV2.4 Mus_musculus gene_expr strna --chip-format 15x3"
    echo ""
    echo "  # scRNA mode"
    echo "  $0 ST110250_A1 scrna_test BBV2.4 Homo_sapiens gene_expr scrna"
    echo ""
    exit 1
fi

export CELATLAS_SAMPLE_NAME="$sample_name"
export CELATLAS_CHIP_NUMBER="$chip_number"

# Validate method
if [[ "$method" != "image" && "$method" != "ssDNA" && "$method" != "gene_expr" && "$method" != "HE" ]]; then
    echo "Error: Invalid method '$method'. Must be 'image', 'ssDNA', 'gene_expr', or 'HE'."
    exit 1
fi

# Map ssDNA to image for backward compatibility
if [[ "$method" == "ssDNA" ]]; then
    echo "Note: Using ssDNA mode (equivalent to image mode)"
    method="image"
fi

# Validate mode
if [[ "$mode" != "scrna" && "$mode" != "strna" ]]; then
    echo "Error: Invalid mode '$mode'. Must be 'scrna' or 'strna'."
    exit 1
fi

# =========================
# Thread Configuration
# =========================
if command -v nproc >/dev/null 2>&1; then
  CPU_CORES=$(nproc)
elif command -v sysctl >/dev/null 2>&1; then
  CPU_CORES=$(sysctl -n hw.ncpu 2>/dev/null || echo 16)
else
  CPU_CORES=16
fi
thread=${THREADS:-$CPU_CORES}

# Limit BLAS library threads to avoid segmentation faults
# OpenBLAS often has a compiled limit of 64 threads
# Using 32 is safer and prevents memory issues
if [ "$thread" -gt 32 ]; then
  blas_threads=32
  echo "Note: Limiting BLAS threads to 32 (user thread count: $thread)"
else
  blas_threads=$thread
fi

export OMP_NUM_THREADS=$thread
export OPENBLAS_NUM_THREADS=$blas_threads
export MKL_NUM_THREADS=$blas_threads
export VECLIB_MAXIMUM_THREADS=$blas_threads
export BLIS_NUM_THREADS=$blas_threads
export NUMEXPR_MAX_THREADS=$thread
export NUMEXPR_NUM_THREADS=$thread

# =========================
# Configuration
# =========================
bin=50
pixelSize=0.5
insertR2=150
cell_num=50000
chip_format=${OPT_CHIP_FORMAT:-auto}
feature_type="gene"
chemistryPattern="C4L15C4L15C4U10T18"

case "$chip_format" in
    auto|15x3|wide|bbox|legacy)
        ;;
    *)
        echo "Error: Invalid --chip-format '${chip_format}'. Must be one of: auto, 15x3, wide, bbox, legacy."
        exit 1
        ;;
esac

# Paths
workspace_dir=${CELATLAS_WORKSPACE:-/home/service/celatlas_spatial}
segImageDir="${workspace_dir}/binSegment/${sample}"
image_dir="${workspace_dir}/images"

# Chemistry directory mapping (for backward compatibility)
chemistry_dir="$chemistry"
if [[ "$chemistry" == "BBV3" ]] || [[ "$chemistry" == "BBV3.1" ]]; then
    chemistry_dir="BBV3.4"
fi

fastq_dir="${workspace_dir}/fastq/$chemistry_dir"
mask_dir="${workspace_dir}/ST_mask"
reference_dir="${workspace_dir}/reference"
src_dir="${workspace_dir}/src"
rawdata_dir="${workspace_dir}/rawdata/$sample"
sampledir="${workspace_dir}/results/${casno}/${sample}"
genomeDir="${reference_dir}/${Species}"

# Prepare log
mkdir -p "${sampledir}"
log_file="${sampledir}/reanalysis_pipeline.log"
exec > >(tee -a "$log_file") 2>&1
echo "======================================"
echo "Starting REANALYSIS pipeline at $(date)"
echo "======================================"
echo "sample=${sample} casno=${casno} chemistry=${chemistry} Species=${Species} method=${method} mode=${mode} threads=${thread} chip_format=${chip_format}"

# =========================
# Prerequisite Checks
# =========================
echo ""
echo "[Prerequisite Check] Verifying required files and directories..."

# Check if 05.count exists (required for reanalysis)
if [[ ! -d "${sampledir}/05.count" ]]; then
    echo "ERROR: 05.count directory not found at ${sampledir}/05.count"
    echo "       Please run the full pipeline first (steps 00-05)"
    exit 1
fi

if [[ ! -f "${sampledir}/05.count/${sample}_count_detail.txt" ]]; then
    echo "ERROR: count_detail.txt not found at ${sampledir}/05.count/${sample}_count_detail.txt"
    echo "       Please run the full pipeline first (steps 00-05)"
    exit 1
fi

echo "✓ Found 05.count directory"
echo "✓ Found count_detail.txt ($(du -h ${sampledir}/05.count/${sample}_count_detail.txt | cut -f1))"

# Check rawdata directory
if [[ ! -d "$rawdata_dir" ]]; then
    echo "ERROR: rawdata directory not found at $rawdata_dir"
    exit 1
fi
echo "✓ Found rawdata directory"

# Check required files based on mode
if [[ "$mode" == "scrna" ]]; then
    required_files=()
    echo "✓ scRNA mode: no spatial files required"
elif [[ "$method" == "image" ]]; then
    required_files=(
        "${rawdata_dir}/${sample}.tif"
        "${rawdata_dir}/${sample}.barcodeToPos.h5"
        "${rawdata_dir}/${sample}_FilterBarcodes.csv"
        "${rawdata_dir}/${sample}_tissue_bbox.csv"
    )
    # Critical check for image mode
    if [[ ! -f "${rawdata_dir}/${sample}.tif" ]]; then
        echo ""
        echo "ERROR: image/ssDNA mode requires tissue image file!"
        echo "       Missing: ${rawdata_dir}/${sample}.tif"
        echo ""
        exit 1
    fi
elif [[ "$method" == "gene_expr" || "$method" == "HE" ]]; then
    required_files=(
        "${rawdata_dir}/${sample}.barcodeToPos.h5"
        "${rawdata_dir}/${sample}_FilterBarcodes.csv"
        "${rawdata_dir}/${sample}_tissue_bbox.csv"
    )
fi

for f in "${required_files[@]}"; do
    if [[ ! -f "$f" ]]; then
        echo ""
        echo "ERROR: Required file not found: $f"
        echo ""
        exit 1
    fi
    echo "✓ Found $(basename $f)"
done

# Check HE image for HE mode
if [[ "$method" == "HE" ]]; then
    he_found=false
    for ext in tif png jpg jpeg; do
        if [[ -f "${rawdata_dir}/${sample}_he.${ext}" ]]; then
            echo "✓ Found HE image: ${sample}_he.${ext}"
            he_found=true
            break
        fi
    done
    if [[ "$he_found" == false ]]; then
        echo "ERROR: HE mode requires HE image but none found!"
        echo "       Searched for: ${rawdata_dir}/${sample}_he.(tif|png|jpg|jpeg)"
        exit 1
    fi
fi

# Check reference genome
if [[ ! -d "${genomeDir}" ]]; then
    echo "ERROR: Reference genome not found at ${genomeDir}"
    exit 1
fi
echo "✓ Found reference genome: ${Species}"

# Set ulimit
ulimit -n 10240

echo ""
echo "[Prerequisite Check] All checks passed!"
echo ""

# =========================
# Clean Previous Results
# =========================
echo "[Cleanup] Removing previous analysis results..."

if [[ -d "${sampledir}/06.binSegment" ]]; then
    echo "  Removing ${sampledir}/06.binSegment/"
    rm -rf "${sampledir}/06.binSegment/"
fi

if [[ -d "${sampledir}/07.analysis" ]]; then
    echo "  Removing ${sampledir}/07.analysis/"
    rm -rf "${sampledir}/07.analysis/"
fi

# Remove old reanalysis reports if they exist
if [[ -f "${sampledir}/${sample}_spatial_analysis_report.html" ]]; then
    echo "  Removing old report: ${sample}_spatial_analysis_report.html"
    rm -f "${sampledir}/${sample}_spatial_analysis_report.html"
fi

echo "[Cleanup] Done"
echo ""

# =========================
# Memory Optimization Settings
# =========================
# Set the maximum parallel jobs for binSegment
# Default: 2 (balances speed and memory)
# - Set to 1 if memory < 100GB
# - Set to 3 if memory > 200GB
export BINSEGMENT_MAX_PARALLEL=${BINSEGMENT_MAX_PARALLEL:-2}

echo "[Memory Settings]"
echo "  BINSEGMENT_MAX_PARALLEL: ${BINSEGMENT_MAX_PARALLEL}"
echo "  Available memory: $(free -h | awk '/^Mem:/ {print $7}') free"
echo "  Thread count: ${thread}"
echo "  Chip format: ${chip_format}"
echo ""

# =========================
# Branch Functions
# =========================

run_image_branch() {
    echo "======================================"
    echo "[Image Mode] Starting image-based segmentation..."
    echo "======================================"

    run_command celatlas_spatial rna binSegment --outdir "${sampledir}/06.binSegment" --sample "${sample}" \
        --thread "${thread}" --genomeDir "${genomeDir}" --pixel-size "${pixelSize}" --input "${rawdata_dir}" \
        --segment --tif "${rawdata_dir}/${sample}.tif" --bs_out "${segImageDir}" --model "${src_dir}/swin_tiny.pth" --method "image" \
        --count --count_detail "${sampledir}/05.count/${sample}_count_detail.txt" \
        --chip-format "${chip_format}"

    echo "[Image Mode] Completed!"
}

run_gene_expr_branch() {
    echo "======================================"
    echo "[Gene Expression Mode] Starting gene expression-based segmentation..."
    echo "======================================"

    local gem_bin_size="${GEM_BIN_SIZE:-20}"
    local umi_threshold="${UMI_MIN_THRESHOLD:-30}"
    local enhance_params='{"p_low":5, "p_high":95, "suppress_noise":true, "noise_threshold":"auto"}'

    echo "[Parameters]"
    echo "  gem_bin_size: ${gem_bin_size} microns"
    echo "  umi_min_threshold: ${umi_threshold}"
    echo "  enhance_params: ${enhance_params}"
    echo ""

    run_command celatlas_spatial rna binSegment --outdir "${sampledir}/06.binSegment" --sample "${sample}" \
        --thread "${thread}" --genomeDir "${genomeDir}" --pixel-size "${pixelSize}" --input "${rawdata_dir}" \
        --segment --model "${src_dir}/swin_tiny.pth" --method "gene_expr" --count \
        --count_detail "${sampledir}/05.count/${sample}_count_detail.txt" \
        --gem-bin-size "${gem_bin_size}" \
        --umi-min-threshold "${umi_threshold}" \
        --enhance-params "${enhance_params}" \
        --chip-format "${chip_format}"

    echo "[Gene Expression Mode] Completed!"
}

run_he_branch() {
    echo "======================================"
    echo "[HE Mode] Starting HE + Gene Expression segmentation..."
    echo "======================================"

    local gem_bin_size="${GEM_BIN_SIZE:-20}"
    local umi_threshold="${UMI_MIN_THRESHOLD:-30}"
    local enhance_params='{"p_low":5, "p_high":95, "suppress_noise":true, "noise_threshold":"auto"}'
    local registration_type="${REGISTRATION_TYPE:-affine}"

    # Find HE image
    he_image_found=""
    for ext in tif png jpg jpeg; do
        if [[ -f "${rawdata_dir}/${sample}_he.${ext}" ]]; then
            he_image_found="${rawdata_dir}/${sample}_he.${ext}"
            break
        fi
    done

    echo "[Parameters]"
    echo "  gem_bin_size: ${gem_bin_size} microns"
    echo "  umi_min_threshold: ${umi_threshold}"
    echo "  enhance_params: ${enhance_params}"
    echo "  registration_type: ${registration_type}"
    echo "  HE image: ${he_image_found}"
    echo ""

    run_command celatlas_spatial rna binSegment --outdir "${sampledir}/06.binSegment" --sample "${sample}" \
        --thread "${thread}" --genomeDir "${genomeDir}" --pixel-size "${pixelSize}" --input "${rawdata_dir}" \
        --segment --model "${src_dir}/swin_tiny.pth" --method "HE" --count \
        --count_detail "${sampledir}/05.count/${sample}_count_detail.txt" \
        --tif "${he_image_found}" \
        --gem-bin-size "${gem_bin_size}" \
        --umi-min-threshold "${umi_threshold}" \
        --enhance-params "${enhance_params}" \
        --registration-type "${registration_type}" \
        --chip-format "${chip_format}"

    echo "[HE Mode] Completed!"
}

# =========================
# Main Reanalysis Logic (Mode Branch)
# =========================

if [[ "$mode" == "scrna" ]]; then
    # =========================
    # scRNA Mode: 06_analysis_wrapper + Report
    # =========================
    echo "======================================"
    echo "scRNA Reanalysis Mode"
    echo "======================================"
    echo ""
    echo "Step 1/2: Running scRNA basic analysis (06_analysis_wrapper)"
    echo "======================================"
    echo ""

    matrix_dir="${sampledir}/05.count/${sample}_filtered_feature_bc_matrix"

    if [[ -d "$matrix_dir" ]]; then
        # Remove old analysis if exists
        if [[ -d "${sampledir}/06_analysis_wrapper" ]]; then
            echo "Removing old analysis: ${sampledir}/06_analysis_wrapper"
            rm -rf "${sampledir}/06_analysis_wrapper"
        fi

        run_command celatlas_spatial rna analysis \
            --outdir "${sampledir}/06_analysis_wrapper" \
            --sample "${sample}" \
            --thread "${thread}" \
            --genomeDir "${genomeDir}" \
            --matrix_file "${matrix_dir}" \
            --assay scrna

        echo "✓ scRNA basic analysis completed: ${sampledir}/06_analysis_wrapper"
    else
        echo "ERROR: Filtered matrix not found at ${matrix_dir}"
        echo "       Please ensure step 05.count completed successfully."
        exit 1
    fi

    echo ""
    echo "======================================"
    echo "Step 2/2: Generating scRNA analysis report"
    echo "======================================"
    echo ""

    out_html="${sample}_scrna_analysis_report.html"

    # Try CLI command first (if installed)
    if command -v celatlas_scrna_report >/dev/null 2>&1; then
        run_command celatlas_scrna_report \
            "${sampledir}" "${sample}" \
            --chemistry "${chemistry}" \
            --species "${Species}" \
            --output-filename "${out_html}" \
            --verbose
        echo "✓ scRNA analysis report generated: ${sampledir}/${out_html}"
    else
        # Fallback to direct Python script
        script_locations=(
            "/home/service/anaconda3/envs/celatlas_spatial/lib/python3.9/site-packages/celatlas_spatial/tools/scrna_report_generator.py"
            "$(dirname "$0")/celatlas_spatial/tools/scrna_report_generator.py"
            "/mnt/strna/software/celatlas_spatial-1.6.0/celatlas_spatial/tools/scrna_report_generator.py"
        )

        scrna_report_generator=""
        for loc in "${script_locations[@]}"; do
            if [[ -f "$loc" ]]; then
                scrna_report_generator="$loc"
                break
            fi
        done

        if [[ -n "$scrna_report_generator" ]]; then
            run_command python3 "$scrna_report_generator" \
                "${sampledir}" \
                "${sample}" \
                --chemistry "${chemistry}" \
                --species "${Species}" \
                --output-filename "${out_html}" \
                --verbose
            echo "✓ scRNA analysis report generated: ${sampledir}/${out_html}"
        else
            echo "WARNING: scRNA report generator not found in any of the following locations:"
            for loc in "${script_locations[@]}"; do
                echo "  - $loc"
            done
            echo "Skipping report generation."
        fi
    fi

    echo ""
    echo "======================================"
    echo "scRNA Reanalysis completed successfully at $(date)"
    echo "======================================"
    echo ""
    echo "Results:"
    echo "  - Analysis:  ${sampledir}/06_analysis_wrapper/"
    echo "  - Report:    ${sampledir}/${out_html}"
    echo ""

else
    # =========================
    # Spatial Mode: binSegment + Analysis + Report
    # =========================
    echo "======================================"
    echo "Spatial Reanalysis Mode"
    echo "======================================"
    echo ""
    echo "Step 1/3: Running binSegment (06.binSegment)"
    echo "======================================"
    echo ""

    # Run appropriate branch based on method
    if [[ "$method" == "image" ]]; then
        run_image_branch
    elif [[ "$method" == "HE" ]]; then
        run_he_branch
    elif [[ "$method" == "gene_expr" ]]; then
        run_gene_expr_branch
    fi

    echo ""

    # =========================
    # 07.analysis
    # =========================
    echo "======================================"
    echo "Step 2/3: Running spatial analysis (07.analysis)"
    echo "======================================"
    echo ""

    # Determine dimensional reduction strategy based on bin size
    # For bin10 (highest resolution, most data points), skip t-SNE to avoid segfault
    # t-SNE is O(n^2) complexity and prone to memory issues with large datasets
    skip_tsne_flag=""
    if [[ "$bin" == "10" ]]; then
        skip_tsne_flag="--skip-tsne"
        echo "[Dimensional Reduction] Bin size: ${bin}µm - Using UMAP only (skipping t-SNE)"
        echo "  Reason: High-resolution data (bin10) has many data points"
        echo "  t-SNE is prone to segmentation fault with large datasets"
        echo "  UMAP provides similar visualization with better performance"
    else
        echo "[Dimensional Reduction] Bin size: ${bin}µm - Using both t-SNE and UMAP"
    fi
    echo ""

    run_command celatlas_spatial rna analysis --outdir "${sampledir}/07.analysis" --sample "${sample}" \
        --thread "${thread}" --genomeDir "${genomeDir}" --square_bin_dir "${sampledir}/06.binSegment/square_bin" \
        --pixel-size "${pixelSize}" --bin "${bin}" ${skip_tsne_flag}

    echo ""

    # =========================
    # 08.report
    # =========================
    echo "======================================"
    echo "Step 3/3: Generating spatial analysis report"
    echo "======================================"
    echo ""

    out_html="${sample}_spatial_analysis_report.html"

    if command -v celatlas_spatial_report >/dev/null 2>&1; then
        run_command celatlas_spatial_report \
            "${sampledir}" "${sample}" \
            --chemistry "${chemistry}" \
            --species "${Species}" \
            --output-filename "${out_html}" \
            --verbose
        echo "✓ Spatial analysis report generated: ${sampledir}/${out_html}"
    else
        # Fallback to Python script
        report_generator="/home/service/anaconda3/envs/celatlas_spatial/lib/python3.9/site-packages/celatlas_spatial/tools/spatial_report_generator.py"
        if [[ -f "$report_generator" ]]; then
            run_command python3 "$report_generator" \
                "${sampledir}" \
                "${sample}" \
                --chemistry "${chemistry}" \
                --species "${Species}" \
                --output-filename "${out_html}" \
                --verbose
            echo "✓ Spatial analysis report generated: ${sampledir}/${out_html}"
        else
            echo "WARNING: Report generator not found. Skipping report."
        fi
    fi

    echo ""
    echo "======================================"
    echo "Spatial Reanalysis completed successfully at $(date)"
    echo "======================================"
    echo ""
    echo "Results:"
    echo "  - binSegment: ${sampledir}/06.binSegment/"
    echo "  - Analysis:   ${sampledir}/07.analysis/"
    echo "  - Report:     ${sampledir}/${out_html}"
    echo ""
fi
